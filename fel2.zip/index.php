<?php
require_once 'functions.php';   // a fenti kóddal ellátott fájl

/* Ha POST kérés, a függvény visszaad egy szöveget, amit kiírunk */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $output = handleLogin();    // nincs echo a függvényen belül
    // a válasz megjelenítése
    echo $output;
    exit;
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Bejelentkezés</title>
</head>
<body>
    <h2>Bejelentkezés</h2>
    <form method="post" action="">
        <label>
            Email:
            <input type="email" name="username" required>
        </label>
        <br><br>
        <label>
            Jelszó:
            <input type="password" name="password" required>
        </label>
        <br><br>
        <button type="submit">Belépés</button>
    </form>
</body>
</html>
